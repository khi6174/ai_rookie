# SafeRoute AI MVP 아키텍처

## 문서 상태

- 상태: Approved
- 담당: 팀 안전빵
- 최종 갱신: 2026-07-18
- 대상: 2026-08-14 본선 중간 결과물과 이후 1차 결선 데모

## 1. 목적

이 문서는 SafeRoute AI의 Approved 제품·데이터·안전·개입·AI 정책을 구현 가능한 모듈과 데이터 흐름으로 연결한다. 목표는 2인 팀이 단일 폐루프를 재현 가능하게 완성하는 것이며, 대규모 운영 인프라를 미리 설계하는 것이 아니다.

## 2. 아키텍처 원칙

1. 안전 계산과 실행 가능성은 순수한 결정론적 코드가 소유한다.
2. 안전 하드 제약을 통과한 후보만 운영 우선순위 비교 대상이 된다.
3. 기사·관리자·고객 설명은 동일한 불변 결정 스냅샷에서 파생한다.
4. 모든 외부·사용자 입력은 경계에서 검증하고 출처와 상태를 보존한다.
5. Live 실패를 숨기지 않고 명시적인 Mock·Error·Fallback으로 전환한다.
6. 실제 TMS가 없는 MVP에서는 계획 적용을 원자적 데모 스냅샷 교체로 모사한다.
7. 합성·시뮬레이션·데모 결과를 실제 안전효과로 표현하지 않는다.

## 3. 시스템 컨텍스트

```text
공개·합성 입력 ─┐
기사 응답 ──────┼─> 데이터 경계와 Zod 검증
날씨·지도 어댑터 ┘          │
                             v
                 Safety Budget / DSE 엔진
                             │
                             v
                    개입 후보·제약 엔진
                             │
                 ┌───────────┴───────────┐
                 v                       v
          기사 검토·동의             관리자 비교·승인
                 └───────────┬───────────┘
                             v
                 계획 재검증·원자적 적용
                             │
                 ┌───────────┴───────────┐
                 v                       v
          고객안내·Upstage 설명        감사·평가 기록
```

## 4. 배포 단위와 기술 스택

### 4.1 단일 애플리케이션

- UI: React, TypeScript, Vite, CSS custom properties
- 계약 검증: Zod
- 서버 경계: Node 전용 평가·Live smoke 어댑터, 본선 P0 배포 서버 없음
- 단위·계약 테스트: Vitest
- E2E·반응형 검증: Playwright
- MVP 저장: 버전된 JSON fixtures와 실행 중 불변 스냅샷

관리자와 기사 화면은 같은 애플리케이션의 역할 전환형 화면으로 구현한다. 기사 화면은 설치형 PWA나 독립 인증 세션이 아닌 반응형 모바일 웹이다. 별도 마이크로서비스, 메시지 브로커, 실시간 데이터베이스는 P0에 도입하지 않는다. 외부 AI·날씨 Live 실행은 브라우저 번들에 포함하지 않고 명시적인 Node smoke 명령에서만 수행한다.

### 4.2 권장 디렉터리

```text
src/
  domain/
    contracts/          # Zod와 TypeScript 도메인 계약
    safety/             # Safety Budget, 기여도, 신뢰도, Time-to-Breach
    interventions/      # 후보 생성, 하드 제약, 추천 순위
    decisions/          # 상태 전이와 불변 결정 스냅샷
  application/
    evaluate-plan/      # 기준 계획 평가 유스케이스
    compare-actions/    # 개입 비교 유스케이스
    consent/            # 기사·수신 기사 응답
    approval/           # 관리자 승인과 재검증
    apply-plan/         # 원자적 계획 적용과 롤백
    notices/            # 고객안내 요청
  adapters/
    fixtures/           # 대표 시나리오와 변형
    weather/            # Live·Mock·Error·Fallback 어댑터
    maps/               # 데모 경로와 향후 지도 공급자 경계
    upstage/            # Parse·Extract·Solar 어댑터
    domestic-ai/        # A.X·K-EXAONE 공통 텍스트 평가와 향후 승인된 에셋 도구 경계
    audit/              # 감사 이벤트 저장 경계
  ui/
    admin/              # Control Tower와 승인 흐름
    courier/            # 기사 반응형 모바일 웹과 Near-miss
    shared/             # 동일 수치·상태 표현 컴포넌트
  demo/
    controller/         # 단계 전환, reset, fallback
    fixtures/           # 고정 데모 manifest
api/                    # P0 미구현, 실제 배포 승인 후 추가
  upstage/              # 향후 비밀정보를 브라우저에 노출하지 않는 서버 함수
  external-data/        # 향후 허용된 외부 조회 프록시
tests/
  fixtures/
  contract/
  e2e/
```

실제 구현 시 파일 수를 불필요하게 늘리지 않고 한 책임이 커질 때만 분리한다.

## 5. 계층별 책임

### 5.1 Domain

- 브라우저, React, 네트워크와 저장소에 의존하지 않는다.
- 같은 입력·설정 버전·기준시각에서 같은 결과를 반환한다.
- 외부에서 검증된 도메인 객체만 받는다.
- Safety Budget, 개입 효과와 추천에 LLM 결과를 입력으로 사용하지 않는다.

### 5.2 Application

- 도메인 함수를 폐루프 상태 전이에 맞게 조합한다.
- 결정 ID와 입력·출력·버전을 하나의 스냅샷으로 묶는다.
- 기사 동의와 관리자 승인을 검증하고 적용 직전 최신 입력으로 재검증한다.
- 실패를 성공 상태로 바꾸지 않으며 마지막 확정 계획을 유지한다.

### 5.3 Adapters

- 외부 응답을 원본 상태 그대로 도메인에 전달하지 않는다.
- Zod 검증, 시간대 정규화, 출처·최신성·결측 메타데이터를 추가한다.
- Live·Mock·Loading·Error·Fallback을 판별 합집합으로 반환한다.
- API 키, 원시 생체값, 정밀 위치와 불필요한 개인정보를 로그에 남기지 않는다.

기상청 DS-001 어댑터는 API허브 4.1 초단기실황과 4.2 초단기예보를 별도 endpoint·스키마로 검증한다. 실황은 현재 기온·강수·습도·풍속·강수형태 후보, 예보는 발표시각부터 최대 6시간의 시간순 기온·강수·습도·풍속·강수형태·하늘·낙뢰 후보로 정규화한다. 원본 hash와 공식 URI·버전·이용정책을 provenance에 기록하지만, `WeatherState` 필수 필드가 모두 충족되지 않아 `safeForSafetyEngine=false`로 격리한다. 이 후보는 추가 출처와 승인된 매핑 없이 Domain 계층으로 전달할 수 없다. 계약용 가짜 응답은 별도의 Demo `MOCK` provenance를 사용한다.

`KMA candidate → coverage Gate → WeatherState` 경계는 강수 정확값·구간값, 체감온도, 시정, 시간당 적설과 노면 상태를 각각 판정한다. 강수 구간은 모델 포화 상한을 이용한 보수적 경계만 허용하고 가정을 기록한다. 체감온도·시정·시간당 적설이 없으면 Gate가 `BLOCKED`를 반환하며, UI와 Safety 엔진은 기존 Demo/Fallback 상태를 유지한다.

DS-005의 1.3 어댑터는 exact endpoint에서 공개 대표점의 현재 `ta_chi`와 `vs`를 읽고 `vs`만 km에서 m로 변환한다. `sd_3hr`는 3시간 신적설 후보로 별도 보존하며 시간당 값으로 나누지 않는다. DS-006의 4.3 어댑터는 최신 공개 발표시각을 선택하고 현재부터 120분 범위의 `SNO·TMP·REH·WSD`를 추출한다. 적설 구간은 중간값 대신 모델 3cm/h 포화 상한에 대한 보수적 경계로 선택하고, 체감온도는 기상청 공식 계절별 식과 적용조건으로만 산출한다. 4.3 최신성은 3시간 발표주기와 제공지연을 반영한 210분으로 별도 검증한다. 이 보완 계층도 미래 시정과 현재 시간당 적설이 없으므로 `safeForSafetyEngine=false`를 유지한다. 원문·인증키·대표점 위경도는 산출물에 저장하지 않는다.

Runtime 선택기는 `safeForSafetyEngine=false`인 KMA evidence와 Demo fixture를 받으면 일부 필드를 섞지 않고 Demo `WeatherState[]` 전체를 `FALLBACK`으로 선택한다. Live evidence는 출처·해시·준비/차단 필드만 별도 보존하고 Safety 엔진에는 전달하지 않는다. 이 선택 결과는 관리자·기사 공통 배지와 감사 패널에 노출되며, 계산 모드는 계속 Demo다.

### 5.4 UI

- 도메인 계산을 다시 구현하지 않는다.
- 관리자와 기사가 동일한 결정 스냅샷을 조회한다.
- 화면은 상태 전이 명령만 요청하고 승인·동의 조건을 우회하지 않는다.
- 색상 외 텍스트·아이콘·수치범위로 상태를 표현한다.

## 6. 핵심 도메인 파이프라인

### 6.1 입력 정규화

1. 원본 데이터와 `Provenance`를 수집한다.
2. Zod 계약으로 타입·범위·시간·참조 무결성을 검증한다.
3. 결측·최신성·출처 상태를 계산한다.
4. 위험 관련 결측은 낙관적 최솟값으로 대체하지 않는다.
5. 검증 실패는 입력 오류 상태로 반환하고 마지막 결과를 현재 Live 결과처럼 재사용하지 않는다.

### 6.2 Safety Budget 평가

1. 현재 Budget과 향후 최대 120분 타임라인을 계산한다.
2. Driver·Task·Route·Weather·Interaction 노출과 유효 Recovery를 분리한다.
3. 반올림 전 값으로 밴드와 첫 초과 시각·배송지를 판정한다.
4. 정렬된 기여도, 신뢰도, 결측과 모델·설정 버전을 반환한다.

### 6.3 개입 비교

1. 휴식, 물량이관, 순서변경, 안전경로, Safe Delay와 호환 묶음을 생성한다.
2. 각 후보의 전체 계획을 다시 평가한다.
3. 안전·용량·시간창·호환성·동의 하드 제약을 검사한다.
4. 불가능 후보에 안정적인 reason code와 사용자 설명을 붙인다.
5. 실행 가능 집합 안에서만 추천 점수를 계산한다.

### 6.4 동의·승인·적용

```text
BASELINE_EVALUATED
→ CANDIDATES_GENERATED
→ CANDIDATES_EVALUATED
→ RIDER_REVIEW_REQUIRED
→ RIDER_CONSENTED
→ ADMIN_APPROVAL_REQUIRED
→ APPROVED
→ REVALIDATING
→ APPLYING_PLAN
→ APPLIED
→ NOTICE_RECORDED
→ CLOSED
```

수정·거절·만료·보류·재검증 요구·적용 실패는 `docs/intervention-policy.md`의 분기 상태를 따른다. UI가 다음 화면으로 이동했다는 이유로 상태를 건너뛰지 않는다.

## 7. 결정 스냅샷과 감사 이벤트

### 7.1 불변 스냅샷

한 결정 ID는 최소 다음을 묶는다.

- 입력 데이터와 provenance 요약
- 모델·설정·계약 버전
- 기준 계획 평가
- 생성된 모든 후보와 불가능 사유
- 기사·수신 기사 응답과 시각
- 관리자 결정과 시각
- 적용 전 재검증 결과
- 적용된 계획과 ETA
- 고객안내와 Upstage 출력 검증 결과
- 전후 지표와 실패·fallback 이벤트

### 7.2 MVP 원자적 적용

`applyPlan`은 승인된 스냅샷 버전과 현재 계획 버전이 일치할 때만 실행한다. 경로·배송순서·기사별 작업목록·ETA를 새 계획 객체로 완성한 뒤 한 번에 활성 계획 참조를 교체한다. 중간 실패 시 기존 활성 계획을 유지하고 `APPLY_FAILED`를 기록한다.

## 8. 국내 AI 트랙 아키텍처

### 8.1 오프라인 합성데이터 계층

| 모델 | 기본 역할 | 입력 | 출력 | 채택 통제 |
|---|---|---|---|---|
| SKT A.X | 공통 텍스트 평가 후 구조화 운영 시나리오 후보 | seed specification·검증된 설명 입력 | strict JSON 후보 | Zod·불변조건·표시값 Gate |
| LG K-EXAONE | 공통 텍스트 평가 후 경계·반례·충돌 변형 | 동일 12과업·검증된 parent record | strict JSON·challenge mutation | 참조·시간·안전·표시값 Gate |
| NC VARCO | P0 관련 사용처 승인 후의 downstream 에셋 후보 | 승인된 텍스트·사실 hash | 3D·이미지/텍스처·음성/사운드 등 해당 제품 에셋 | 제품별 계약·Synthetic 라벨·사실 불변 Gate |
| Upstage | 문서 왕복 검증 | 합성 문서·스키마 | Parse·Extract 결과 | Zod·source citation 검증 |

생성 AI는 정답 Safety Budget, 추천 후보와 합격 라벨을 만들지 않는다. 결정론 엔진이 채택된 입력을 라벨링한다. 모든 산출물에는 모델, 프롬프트 버전, seed, parent ID, 검증 결과와 거절 사유를 기록한다. 대회 제공 가이드에서 동일한 OpenAI-compatible 텍스트 계약이 확인된 A.X K1과 K-EXAONE만 공통 12과업으로 비교하며, VARCO를 텍스트 LLM으로 추정하지 않는다.

### 8.2 제품 런타임 Upstage 계층

```text
합성 안전문서
→ Document Parse
→ 허용 필드 Information Extract
→ Zod 검증 + 출처 페이지/섹션 고정
→ 결정론적 결과 JSON과 결합
→ Solar 역할별 strict JSON 설명
→ 숫자 불변·인용·금지문구 검증
→ UI 또는 결정론적 템플릿 fallback
```

Solar 출력은 설명문만 제공하며 Safety Budget, 실행 가능성, 추천과 적용 상태를 변경할 권한이 없다.

현재 MVP 구현은 합성 안전문서 fixture, strict 설명 계약, Upstage Mock 어댑터와 timeout·malformed·무결성 실패용 결정론적 템플릿 Fallback을 포함한다. 서버 전용 Live 어댑터는 공식 HTTPS chat endpoint만 허용하고 API 키·모델·timeout·크기 제한을 명시적으로 주입받으며 브라우저 실행을 차단한다. Upstage `solar-pro3` Live 12과업은 11건을 승인하고 malformed 1건을 Fallback으로 전환했다. A.X·K-EXAONE 공통 서버 어댑터는 대회 문서 endpoint를 exact allowlist로 고정했고 Mock 24과업 계약을 통과했지만, 두 API의 Live 모델 결과는 아직 실행 증거로 기록하지 않는다. Mock을 Live로 표시하지 않는다.

### 8.3 연구인프라 활용

- 국내 AI API: 동일한 10~20개 smoke 과업으로 구조 유효성, 제약 위반, 지연, 비용과 중복을 비교한다.
- A100: 로컬 오픈 웨이트 생성 기준선, 임베딩 기반 중복·커버리지 분석을 우선한다.
- 조건부 학습: 데이터량과 검증셋이 충분하고 기준선 대비 개선을 측정할 수 있을 때만 수행한다.
- 증빙: 실행 명령, 환경, 모델·프롬프트 버전, 사용량, 결과 CSV와 실패 로그를 보존한다.

## 9. 오류와 Fallback

| 실패 | 사용자 상태 | 도메인 행동 |
|---|---|---|
| 필수 입력 검증 실패 | `DATA_ERROR` | 계산 차단, 누락·오류 목록 제공 |
| 일부 결측 | 낮은 신뢰도와 결측 표시 | 보수적 대체와 가정 기록 또는 계산 차단 |
| 개입 생성 실패 | `OPTIONS_ERROR` | 기준 예측 유지, 계획 미변경 |
| 안전 후보 없음 | `NO_SAFE_OPTION` | Safe Delay·물량감축 요청, 강제 추천 금지 |
| Upstage 실패 | `FALLBACK` | 수치·추천 유지, 템플릿 설명 사용 |
| 계획 적용 실패 | `APPLY_FAILED` | 마지막 확정 계획 유지 |
| Live 데모 실패 | `DEMO_FALLBACK` | 고정 fixture로 전환하고 배지 유지 |

## 10. 보안·개인정보 경계

- 비밀정보는 서버 함수 환경변수에 두고 브라우저 번들·로그·fixture에 넣지 않는다.
- 관리자에게 원시 심박·수면·정밀 이동궤적을 제공하지 않는다.
- Near-miss는 거친 위치와 검증 상태만 관리자 화면에 제공한다.
- 자유문은 보존 전 개인정보 검사를 거치며 데모에는 합성 텍스트만 사용한다.
- Upstage 입력은 허용 목록 방식으로 구성하고 불필요한 식별자를 제거한다.

## 11. 테스트 경계

- Domain: 정확값, 경계, 단조성, 메타모픽, Risk Transfer Guard
- Contracts: 잘못된 범위·시간·참조·판별 상태 거절
- Application: 허용 상태 전이, 재동의, 승인 직전 재검증, 원자적 적용
- AI adapters: malformed·timeout·prompt injection·숫자 불변·인용 검증
- UI/E2E: 동일 결정 ID, 키보드, 모바일 터치, 오류·fallback·reset
- Demo: clean start에서 동일 시나리오 3회 연속 통과

구체적인 지표와 통과 기준은 `docs/evals.md`가 소유한다.

## 12. 구현 순서

1. 프로젝트 골격과 계약 스키마
2. 세 대표 fixtures와 manifest
3. Safety Budget·Time-to-Breach 엔진
4. 개입 엔진과 Risk Transfer Guard
5. 결정 상태기계와 원자적 적용
6. 관리자 폐루프
7. 기사 동의 폐루프
8. Upstage 문서·설명 계층
9. 평가 하네스와 국내 AI benchmark
10. 데모 모드·접근성·독립 검증

## 13. 심사기준과 아키텍처 증거

| 기준 | 설계 대응 | 구현 후 필요한 증거 |
|---|---|---|
| 창의성 | Time-to-Breach·반사실적 개입·Two-Key Control | 한 결정 ID의 전체 폐루프 영상 |
| 혁신성 | 안전 하드 제약·Risk Transfer Guard·LLM 권한 분리 | 빠르지만 불안전한 후보 차단 테스트 |
| 추진성 | 단일 배포 단위·단계별 구현 순서 | 주차별 커밋, 빌드, 테스트 결과 |
| 성장성 | 어댑터 경계·모델 benchmark·versioned config | 국내 AI 비교 CSV와 향후 Live 교체 경로 |
| 실효성 | 원자적 계획 적용·동일 근거 UI | 기사 동의 후 경로·ETA 갱신 E2E |
| 가치성 | 비징벌성·형평성·개인정보 최소화 | 안전·지연·형평성·감사 지표 |

## 14. 수용기준

- 모든 핵심 수치와 추천은 Domain 계층에서만 생성된다.
- 기사와 관리자는 같은 결정 ID와 평가 스냅샷을 사용한다.
- 안전 하드 제약을 UI·관리자·LLM이 우회할 수 없다.
- 계획 적용은 전부 성공하거나 기존 계획을 유지한다.
- 외부 어댑터는 출처와 Live·Mock·Error·Fallback 상태를 잃지 않는다.
- 국내 AI와 A100 사용에는 재현 명령과 품질·비용·실패 증거가 남는다.
- 아키텍처가 `docs/product-spec.md`의 AC-01~AC-10을 추적할 수 있다.

## 15. 비목표

- 실제 TMS·WMS·고객 메시징 연동
- 대규모 다허브 최적화와 실시간 스트리밍 인프라
- 실제 사고확률·의료 진단 모델
- 완전한 인증·권한·법적 준수 구현
- 독자 지도·내비게이션 엔진
- 검증 목적이 없는 장식성 모델 학습

## 16. 미결사항

- 실제 지도 공급자 또는 정적 데모 지도 구현 방식
- MVP 감사 스냅샷의 파일·브라우저 메모리 저장 선택
- 실제 파일럿 서버 함수의 API 경로와 배포 환경
- 공급자별 국내 AI 모델명·엔드포인트·쿼터
- Upstage timeout·retry·회로차단 수치
- Near-miss GeoHash 정밀도와 검증 워크플로
- 외부 TMS 연결 시 원자적 적용·보상 트랜잭션
