# SafeRoute AI 국내 AI 트랙 제출 패키지

- Git commit: 8da112570e7792fda9d089cd32c337296f1639e7
- 최종 릴리스 게이트: PASSED
- 국내 AI 트랙 감사: PASSED
- 데이터: 합성 Demo fixture, 공개 날씨 증거, 비식별 AI 평가 요약

## 실행

```powershell
pnpm install --frozen-lockfile
pnpm run verify:final
pnpm run dev
```

`demo-dist/`는 같은 commit에서 생성한 정적 빌드다. 실제 기사 개인정보, 실제 TMS·지도·인증·고객 발송은 포함하지 않는다.

## 명시적 제외

- 격리형 ChatGPT 디자인 프로토타입과 압축파일
- 로컬 API 키와 `.env.local`
- `node_modules`, 테스트 리포트와 이전 중복 평가 run

OpenAI-compatible 표기는 통신 형식 이름이며 OpenAI 모델·서비스 사용을 의미하지 않는다.
